FOXFIRE TRAIL — SITE FILES
Samantha & Nicholas · December 12, 2026

WHAT'S HERE
Six self-contained HTML files, one per scavenger hunt stop. Each file has
everything it needs (styles, fonts link, image, script) baked in — just
upload them to any web host and they'll work.

  01-fox.html          Stop 1 · The Fox statue        password to unlock: FIRELIGHT
  02-tree.html         Stop 2 · The old tree          password to unlock: PINECONE
  03-butterflies.html  Stop 3 · The butterfly room    password to unlock: MONARCH
  04-pondhouse.html    Stop 4 · The pond house        password to unlock: DRIFTWOOD
  05-record.html       Stop 5 · The record player     password to unlock: ENCORE
  06-lastclue.html     Stop 6 · Last call (bartender)  password to unlock: NIGHTCAP

Each page's own next password (the one guests need for the FOLLOWING stop)
is shown on that page once it's unlocked — you don't need to memorize the
list above, it's just here for your reference.

HOW TO HOST THEM
Upload the folder to any static host — this can be a subfolder of your own
domain (e.g. yourdomain.com/hunt/), a free static host (Netlify, GitHub
Pages, Cloudflare Pages), or anywhere else that serves plain HTML files.
No server, database, or build step is required.

IMPORTANT — QR CODES STILL NEED TO BE MADE
The QR codes are generated separately, AFTER you know the final URL of each
page. Once these files are uploaded somewhere, send me the live URLs (or
just the domain + folder, if the filenames above stay the same) and I'll
generate the final set of scannable QR codes to match.

A FEW NOTES
- The password gate is client-side only — it's there to stop guests from
  accidentally skipping a clue, not real security. Anyone who viewed the
  page's source could find the password. That's expected and fine for a
  wedding scavenger hunt.
- Each page remembers (per device, via the browser's local storage) once a
  guest has unlocked it, so refreshing won't re-lock it on them.
- If you ever want to change wording, colors, or anything else, just tell
  me what to change and I'll regenerate these files.
